
package util;
import java.sql.*;
public class DatabaseUtil {
    public static Connection getConnection() throws SQLException {
        return DriverManager.getConnection(
        "jdbc:mysql://localhost:3306/mindfulness","root","password");
    }
}
