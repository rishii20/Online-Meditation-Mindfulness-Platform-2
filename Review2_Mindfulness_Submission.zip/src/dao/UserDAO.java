
package dao;
import model.User;
public interface UserDAO {
    User login(String email,String password);
}
