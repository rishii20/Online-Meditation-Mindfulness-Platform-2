
package dao;
import model.User;
import util.DatabaseUtil;
import java.sql.*;
public class UserDAOImpl implements UserDAO {
    public User login(String email,String password){
        try(Connection c=DatabaseUtil.getConnection()){
            PreparedStatement ps=c.prepareStatement(
            "SELECT * FROM users WHERE email=? AND password=?");
            ps.setString(1,email);
            ps.setString(2,password);
            ResultSet r=ps.executeQuery();
            if(r.next()){
                User u=new User();
                u.id=r.getInt("user_id");
                u.name=r.getString("name");
                u.email=r.getString("email");
                u.role=r.getString("role");
                return u;
            }
        }catch(Exception e){e.printStackTrace();}
        return null;
    }
}
