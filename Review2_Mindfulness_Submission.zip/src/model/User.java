
package model;
public class User {
    public int id;
    public String name,email,role;
}
