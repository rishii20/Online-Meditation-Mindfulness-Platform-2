
package controller;
import dao.*;
import model.User;
import util.ValidationUtil;
import javax.servlet.*;
import javax.servlet.http.*;
import java.io.IOException;

public class LoginServlet extends HttpServlet {
    protected void doPost(HttpServletRequest r,HttpServletResponse s)
    throws IOException,ServletException{
        String email=r.getParameter("email");
        String pass=r.getParameter("password");
        if(!ValidationUtil.isValidEmail(email)){
            r.setAttribute("error","Invalid Email");
            r.getRequestDispatcher("jsp/error.jsp").forward(r,s);
            return;
        }
        User user=new UserDAOImpl().login(email,pass);
        if(user==null){
            r.setAttribute("error","Login Failed");
            r.getRequestDispatcher("jsp/error.jsp").forward(r,s);
            return;
        }
        if(user.role.equals("admin")) s.sendRedirect("jsp/admin.jsp");
        else s.sendRedirect("jsp/user.jsp");
    }
}
